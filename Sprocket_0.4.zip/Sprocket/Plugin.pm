# Copyright (c) 2019 Alex Harper
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are
# met:
#
#     (1) Redistributions of source code must retain the above copyright
#     notice, this list of conditions and the following disclaimer.
#
#     (2) Redistributions in binary form must reproduce the above copyright
#     notice, this list of conditions and the following disclaimer in
#     the documentation and/or other materials provided with the
#     distribution.
#
#     (3)The name of the author may not be used to
#     endorse or promote products derived from this software without
#     specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
# IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
# WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
# DISCLAIMED. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT,
# INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
# (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
# SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
# HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
# STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
# IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
# POSSIBILITY OF SUCH DAMAGE.

package Plugins::Sprocket::Plugin;

use strict;
use warnings;
use base qw(Slim::Plugin::OPMLBased);

use Time::HiRes;

use Slim::Buttons::Common;
use Slim::Utils::Log;
use Slim::Utils::Prefs;
use Slim::Utils::Strings qw(string cstring);
use Slim::Utils::Text;
use Slim::Web::ImageProxy;

use Plugins::Sprocket::API;
use Plugins::Sprocket::Settings;
use Plugins::Sprocket::URL;

my $log = Slim::Utils::Log->addLogCategory({
	'category'     => 'plugin.sprocket',
	'defaultLevel' => 'INFO',
	'description'  => 'PLUGIN_SPROCKET',
});


use constant TRICK_PLAY_MODE => 'sprockettricks';

use constant UNICODE_BULLET => "\x{2022}";

my $prefs = preferences('plugin.sprocket');

sub initPlugin {
    my ($class) = @_;

	if (main::WEBUI) {
		Plugins::Sprocket::Settings->new();
	}

	Slim::Player::ProtocolHandlers->registerHandler(
		sprocket => 'Plugins::Sprocket::ProtocolHandler'
	);

	# Should we be doing Slim::Menu::TrackInfo->registerInfoProvider()?
	# Not clear that applies to our usage.

	# Hook various events so we can update playback state.
	Slim::Control::Request::subscribe(\&_PlaybackStateNewSongCallback, [['playlist'], ['newsong']]);
	Slim::Control::Request::subscribe(\&_PlaybackStateSongPauseCallback, [['playlist'], ['pause']]);
	Slim::Control::Request::subscribe(\&_PlaybackStateSongStopCallback, [['playlist'], ['stop']]);

	# Setup for our trick play mode if enabled.
	Slim::Buttons::Common::addMode(TRICK_PLAY_MODE, _TrickPlayModeButtonFunctions(), \&_SetTrickPlayMode);
	Slim::Control::Request::subscribe(\&_TrickPlayPlaybackStateCallback, [['playlist'], ['newsong','pause','stop']]);

    $class->SUPER::initPlugin(
    	feed   => \&_RootMenu,
    	tag    => 'sprocket',
		menu   => 'radios',
		is_app => 1,
		weight => 10,
    );
}

sub getDisplayName {
    return 'PLUGIN_SPROCKET';
}

sub playerMenu {
	# Don't add this plugin to the Extras menu
}

##############################################
#
#  Trick play mode.
#
##############################################

sub _SetTrickPlayMode {
	my ($client, $method) = @_;

	if ($method eq 'pop') {
		Slim::Buttons::Common::popMode($client);
		return;
	}

	# Nothing else is done here, this mode has no UI.
}

sub _PopTrickPlayMode {
	my ($client) = @_;

	# Just in case we pushed it multiple times.
	while ($client->getMode() eq TRICK_PLAY_MODE) {
		Slim::Buttons::Common::popMode($client);
		$log->info("Podcast trick play mode removed.");
	}
}

sub _TrickPlayModeButtonFunctions {
	return {
		'rew' => \&_TrickPlayRewind,
		'fwd' => \&_TrickPlayForward,
		'jump' => sub {
			my ($client, $function, $arg) = @_;
			if ($arg eq 'rew') {
				_TrickPlayRewind($client);
			} elsif ($arg eq 'fwd') {
				_TrickPlayForward($client);
			} else {
				$log->error("Don't know how to jump like \"$arg\".");
			}
		},
	}
}

sub _TrickPlayPlaybackStateCallback {
	my ($request) = @_;
	my $client = $request->client();

	if (!$client) {
		return;
	}

	my $url = Slim::Player::Playlist::url($client);

	if (Plugins::Sprocket::Settings::PlaybackSkipButtons() &&
		$url && Plugins::Sprocket::URL::IsOurURL($url)) {
		# Add our trick play mode.
		if ($client->getMode() ne TRICK_PLAY_MODE) {
			Slim::Buttons::Common::pushMode($client, TRICK_PLAY_MODE);
			$log->info("Entering podcast trick play mode.");
		}
	} else {
		_PopTrickPlayMode($client);
	}
}

sub _TrickPlayRewind {
	my ($client) = @_;

	my $url = Slim::Player::Playlist::url($client);
	if (!$url || !Plugins::Sprocket::URL::IsOurURL($url)) {
		$log->error("Trick play mode engaged outside a podcast.");
		_PopTrickPlayMode($client);
		return;
	}

	# We don't check that trick play is enabled here because the fact this is being called
	# is an indication it is. We don't want to eat the button. Allow other code to tear down
	# the mode setup.

	my $currentTime = Slim::Player::Source::songTime($client);
	my $skipSecs = Plugins::Sprocket::Settings::PlaybackSkipBackwardsSeconds();
	my $playbackSpeed = $client->pluginData('playbackSpeed');

	if ($playbackSpeed) {
		my $adjustedSkipSecs = $skipSecs / $playbackSpeed;
		my $skipTime = $currentTime - $adjustedSkipSecs;
		if ($skipTime < 0) {
			$skipTime = 0;
		}
		$log->debug("Podcast trick rewind to $skipTime (-$adjustedSkipSecs / -$skipSecs)");
		Slim::Player::Source::gototime($client, $skipTime);
	} else {
		$log->error("Podcast trick rewind can't determine playback speed.");
	}
}

sub _TrickPlayForward {
	my ($client) = @_;

	my $url = Slim::Player::Playlist::url($client);
	if (!$url || !Plugins::Sprocket::URL::IsOurURL($url)) {
		$log->error("Trick play mode engaged outside a podcast.");
		_PopTrickPlayMode($client);
		return;
	}

	# We don't check that trick play is enabled here because the fact this is being called
	# is an indication it is. We don't want to eat the button. Allow other code to tear down
	# the mode setup.

	my $currentTime = Slim::Player::Source::songTime($client);
	my $duration = Slim::Player::Source::playingSongDuration($client);
	my $skipSecs = Plugins::Sprocket::Settings::PlaybackSkipForwardsSeconds();
	my $playbackSpeed = $client->pluginData('playbackSpeed');

	if ($playbackSpeed) {
		my $adjustedSkipSecs = $skipSecs / $playbackSpeed;
		my $skipTime = $currentTime + $adjustedSkipSecs;
		# Limit to before end of track if we know it.
		if ($duration && ($skipTime >= ($duration - 5))) {
			$skipTime = $duration - 5;
		}
		# Song too short?
		if ($skipTime < 0) {
			$skipTime = 0;
		}
		$log->debug("Trick forward to $skipTime (+$adjustedSkipSecs / +skipSecs)");
		Slim::Player::Source::gototime($client, $skipTime);
	} else {
		$log->error("Podcast trick forward can't determine playback speed.");
	}
}


##############################################
#
#  Playback State
#
##############################################

sub ClearClientPlaybackState {
	my ($client) = @_;

	$log->debug("Clearing all playback state monitoring.");

	_CancelPlaybackStateProgressTimer($client);

	# We can't set values to undef, so get the whole namespace and modify.
	my $allData = $client->pluginData();
	delete($allData->{episode});
	delete($allData->{playingEpisode});
	delete($allData->{playbackSpeed});
	delete($allData->{playingEpisodePlaybackSpeed});
	delete($allData->{didPlayedToEpisode});
	delete($allData->{progressTime});
	delete($allData->{progressEpisode});
}

sub _UpdateServerEpisodePlaybackStateIfNeeded {
	my ($client, $episode, $position, $playingStatus) = @_;

	if (!Plugins::Sprocket::Settings::IntegratePlaybackState()) {
		$log->debug("Disabled integration for playback state of episode " . $episode->{'uuid'} . ".");
		return;
	}

	$position = int($position);

	# Look for a substantial change.
	my $needsUpdate = 0;
	if (!defined($episode->{'playingStatus'}) || ($episode->{'playingStatus'} != $playingStatus)) {
		$needsUpdate = 1;
	}
	if (defined($episode->{'playedUpTo'})) {
		if (abs($episode->{'playedUpTo'} - $position) > 5) {
			$needsUpdate = 1;
		}
	} else {
		$needsUpdate = 1;
	}

	if (!$needsUpdate) {
		$log->debug("Ignoring no-op playback state change for episode " . $episode->{'uuid'} . ".");
		return;
	}

	$log->debug("Updating server playback state for episode " . $episode->{'uuid'} . ", position $position playingStatus $playingStatus.");
	Plugins::Sprocket::API::UpdateEpisodePlayStatus(
		$episode,
		$position,
		$playingStatus,
		sub {
			my ($updatedEpisode) = @_;

			# After an update from the server we might need to update the current episode.
			my $currentEpisode = $client->pluginData('episode');
			if ($currentEpisode && defined($updatedEpisode) && ($currentEpisode->{'uuid'} eq $updatedEpisode->{'uuid'})) {
				$log->debug("Updating with latest server data for episode " . $currentEpisode->{'uuid'} . ".");
				$client->pluginData( episode => $updatedEpisode );
			}
		},
	);
}

sub _UpdatePlaybackStateForPriorEpisode {
	my ($client) = @_;

	# No check for server integration options here, this method calls through to methods that
	# check that state.

	my $priorEpisode = $client->pluginData('playingEpisode');
	my $priorPlaybackSpeed = $client->pluginData('playingEpisodePlaybackSpeed');
	my $progressEpisode = $client->pluginData('progressEpisode');
	my $progressTime = $client->pluginData('progressTime');

	if (defined($priorEpisode) && defined($priorPlaybackSpeed) && defined($progressEpisode) && defined($progressTime)) {
		if ($priorEpisode->{'uuid'} eq $progressEpisode->{'uuid'}) {
			my $position = $progressTime * $priorPlaybackSpeed;
			my $playingStatus = Plugins::Sprocket::API::PlayStatusPlaying;
			# Prior episodes are the case where we might want to mark things as played. Allow some slop at the end of an episode.
			my $playedToEnd = 0;
			if (($position + 5) >= $priorEpisode->{'duration'}) {
				$playingStatus = Plugins::Sprocket::API::PlayStatusPlayed;
				$playedToEnd = 1;
			}
			$log->debug("Updating server playback state for previous episode " . $priorEpisode->{'uuid'} . ".");
			_UpdateServerEpisodePlaybackStateIfNeeded(
				$client,
				$priorEpisode,
				$position,
				$playingStatus
			);

			if ($playedToEnd && Plugins::Sprocket::Settings::IntegrateUpNextRemovePlayed()) {
				$log->debug("Removing played episode " . $priorEpisode->{'uuid'} . " from Up Next.");
				Plugins::Sprocket::API::RemoveEpisodeFromUpNext($priorEpisode, sub {
					$log->debug("Episode " . $priorEpisode->{'uuid'} . " removed from Up Next.");
				});
			}
		}
	}

	# Clear the values that represent the prior episode.
	my $allData = $client->pluginData();
	delete($allData->{playingEpisode});
	delete($allData->{playingEpisodePlaybackSpeed});
}

sub _PlaybackStateNewSongCallback {
	my ($request) = @_;

	$log->debug("Playback state new song handling: " . $request->getRequestString());

	my $client = $request->client();
	if (!$client) {
		return;
	}

	# If synced, only listen to the master.
	if ($client->isSynced() && !Slim::Player::Sync::isMaster($client)) {
	   	ClearClientPlaybackState($client);  # Safe to clear any non-master state.
		return;
	}

	my $url = Slim::Player::Playlist::url($client);

	# Handle the current song.
	if ($url && Plugins::Sprocket::URL::IsOurURL($url)) {
		my $episode = $client->pluginData('episode');
		if (!$episode) {
			$log->error("Playback state new song handler missing episode info.");
			return;  # Nothing useful we can do, but the URL still belongs to us so don't clear anything.
		}
		my $playbackSpeed = $client->pluginData('playbackSpeed');
		if (!$playbackSpeed) {
			$log->error("Playback state new song handler missing playback speed info.");
			return;  # Nothing useful we can do, but the URL still belongs to us so don't clear anything.
		}
		if ($episode->{'uuid'} ne Plugins::Sprocket::URL::EpisodeUUIDFromHandlerURL($url)) {
			$log->error("Playback state new song handler wrong episode for URL.");
			return;
		}


		# Check to see if the song has changed.
		my $playingEpisode = $client->pluginData('playingEpisode');
		if (defined($playingEpisode) && ($playingEpisode->{'uuid'} ne $episode->{'uuid'})) {
			$log->debug("Playback state episode change from " . $playingEpisode->{'uuid'} . " to " . $episode->{'uuid'} . ".");
			_UpdatePlaybackStateForPriorEpisode($client);
		}

		# Now store the current episode from the protocol handler so we can find it later.
		$client->pluginData( playingEpisode => $episode );
		$client->pluginData( playingEpisodePlaybackSpeed => $playbackSpeed );

		# Configure a progress timer if it doesn't already exist. No need to check play state here.
		_SchedulePlaybackStateProgressTimer($client);

		# Handle various integration options.
		if (Plugins::Sprocket::Settings::IntegratePlaybackState()) {
			# Handle skip to prior position. This is based on similar logic in the default LMS Podcast app.
			my $didPlayedToEpisode= $client->pluginData('didPlayedToEpisode');
			my $songTime = Slim::Player::Source::songTime($client);
			my $alreadySetPlaybackPostion = 0;

			if ($playbackSpeed && defined($episode->{'playedUpTo'}) && ($episode->{'playedUpTo'} > 0)) {
				$log->debug("Episode " .  $episode->{'uuid'} . " candidate for playedUpTo " . $episode->{'playedUpTo'} . " x " . $playbackSpeed);
				if (!defined($didPlayedToEpisode) || ($didPlayedToEpisode->{'uuid'} ne $episode->{'uuid'})) {
					# Even if we choose not to jump, mark that we have evaluated this feature.
					$client->pluginData( didPlayedToEpisode => $episode );

					if (defined($episode->{'duration'}) && (($episode->{'playedUpTo'} + 10) < $episode->{'duration'})) {
						# Restore time needs to be relative to current playback speed.
						my $restoreTime = int($episode->{'playedUpTo'} / $playbackSpeed);
						# Only jump if it's a real change..
						if ($restoreTime > ($songTime + 5)) {
							$log->error("Skipping to previous play position " . $episode->{'playedUpTo'} . " x " . $playbackSpeed);
							Slim::Player::Source::gototime($client, $restoreTime);
							_UpdateServerEpisodePlaybackStateIfNeeded(
								$client,
								$episode,
								$episode->{'playedUpTo'},
								Plugins::Sprocket::API::PlayStatusPlaying
							);
							$alreadySetPlaybackPostion = 1;
						} else {
							$log->debug("Episode " .  $episode->{'uuid'} . " avoiding playedUpTo, not enough of a change.");
						}
					} else {
						$log->debug("Episode " .  $episode->{'uuid'} . " avoiding playedUpTo, would push to close to end.");
					}
				} else {
					$log->debug("Episode " .  $episode->{'uuid'} . " already skipped for playedUpTo.");
				}
			} else {
				$log->debug("Episode " .  $episode->{'uuid'} . " not suitable for playedUpTo.");
			}

			# If skip to prior playback position didn't already update the server, do so now.
			if (!$alreadySetPlaybackPostion && $playbackSpeed) {
				my $realOffset = int($songTime * $playbackSpeed);
				if ($realOffset > $episode->{'duration'}) {
					$realOffset = $episode->{'duration'};
				}
				_UpdateServerEpisodePlaybackStateIfNeeded(
					$client,
					$episode,
					$realOffset,
					Plugins::Sprocket::API::PlayStatusPlaying
				);
			}
		}

		if (Plugins::Sprocket::Settings::IntegrateUpNextCurrentlyPlaying()) {
			$log->debug("Marking episode " .  $episode->{'uuid'} . " as current in Up Next.");
			Plugins::Sprocket::API::SetEpisodeAsCurrentUpNext($episode, sub {
				$log->debug("Up Next update complete.");
				# It would be nice to force the UI to refresh here, but I haven't found a way to do that.
			});
		}

	} else {
		# If the prior song was ours, we might need to update
		if ($client->pluginData('playingEpisode')) {
			_UpdatePlaybackStateForPriorEpisode($client);
		}

		# When its not our song clear all state.
		ClearClientPlaybackState($client);
	}
}

sub _PlaybackStateSongPauseCallback {
	my ($request) = @_;

	$log->debug("Playback state pause handling: " . $request->getRequestString());

	my $client = $request->client();
	if (!$client) {
		return;
	}

	# If synced, only listen to the master.
	if ($client->isSynced() && !Slim::Player::Sync::isMaster($client)) {
	   	ClearClientPlaybackState($client);  # Safe to clear any non-master state.
		return;
	}

	my $url = Slim::Player::Playlist::url($client);
	if ($url && Plugins::Sprocket::URL::IsOurURL($url)) {
		my $episode = $client->pluginData('episode');
		if (!$episode) {
			$log->error("Playback state pause handler missing episode info.");
			return;  # Nothing useful we can do, but the URL still belongs to us.
		}
		if ($episode->{'uuid'} ne Plugins::Sprocket::URL::EpisodeUUIDFromHandlerURL($url)) {
			$log->error("Playback state pause handler wrong episode for URL.");
			return;
		}

		# Sometimes pause is called when a track comes out of pause. In those cases, start timer.
		if ($client->isPlaying()) {
			_SchedulePlaybackStateProgressTimer($client);
		}

		my $currentTime = Slim::Player::Source::songTime($client);
		my $playbackSpeed = $client->pluginData('playbackSpeed');

		if (defined($currentTime) && defined($playbackSpeed)) {
			my $realOffset = int($currentTime * $playbackSpeed);
		  	if ($realOffset > $episode->{'duration'}) {
		    	$realOffset = $episode->{'duration'};
			}
			$log->info("Setting playback position of paused episode " . $episode->{'uuid'} . " to $realOffset ($currentTime x $playbackSpeed).");
			_UpdateServerEpisodePlaybackStateIfNeeded(
				$client,
				$episode,
				$realOffset,
				Plugins::Sprocket::API::PlayStatusPlaying
			);
		}
	} else {
		# When its not our song clear all state. We don't check prior song here because we're paused.
		ClearClientPlaybackState($client);
	}
}

sub _PlaybackStateSongStopCallback {
	my ($request) = @_;

	$log->debug("Playback state stop handling: " . $request->getRequestString());

	my $client = $request->client();
	if (!$client) {
		return;
	}

	# If synced, only listen to the master.
	if ($client->isSynced() && !Slim::Player::Sync::isMaster($client)) {
	   	ClearClientPlaybackState($client);  # Safe to clear any non-master state.
		return;
	}

	# If the prior song was ours, we might need to update
	if ($client->pluginData('playingEpisode')) {
		_UpdatePlaybackStateForPriorEpisode($client);
	}

	# We're stopped, so clear all state.
	ClearClientPlaybackState($client);
}

sub _CancelPlaybackStateProgressTimer {
	my ($client) = @_;
	if (!$client) {
		return;
	}

	my $progressTimer = $client->pluginData('progressTimer');
	if ($progressTimer) {
		Slim::Utils::Timers::killSpecific($progressTimer);
	}
	my $allData = $client->pluginData();
	delete($allData->{progressTimer});
}

sub _SchedulePlaybackStateProgressTimer {
	my ($client) = @_;
	if (!$client) {
		return;
	}

	_CancelPlaybackStateProgressTimer($client);

	my $progressTimer = Slim::Utils::Timers::setTimer(
		$client,
		Time::HiRes::time() + 1,
		\&_PlaybackStateProgressTrackingCallback,
	);
	$client->pluginData( progressTimer => $progressTimer );
}

sub _PlaybackStateProgressTrackingCallback {
	my ($client) = @_;
	if (!$client) {
		return;
	}

	# If synced, only listen to the master.
	if ($client->isSynced() && !Slim::Player::Sync::isMaster($client)) {
	   	ClearClientPlaybackState($client);  # Safe to clear any non-master state.
		return;
	}


	my $url = Slim::Player::Playlist::url($client);
	if ($url && Plugins::Sprocket::URL::IsOurURL($url)) {
		my $songTime = Slim::Player::Source::songTime($client);
		my $episode = $client->pluginData('episode');
		if ($episode) {
			# $log->debug("Tracking progress $songTime in episode " . $episode->{'uuid'} . ".");
			$client->pluginData( progressTime => $songTime );
			$client->pluginData( progressEpisode => $episode );
		} else {
			# $log->debug("Tracking progress, no episode found.");
			my $allData = $client->pluginData();
			delete($allData->{progressTime});
			delete($allData->{progressEpisode});
		}
		# Schedule next fire if we are playing.
		if ($client->isPlaying()) {
			_SchedulePlaybackStateProgressTimer($client);
		} else {
			_CancelPlaybackStateProgressTimer($client);
		}
	} else {
		# If the client is stopped we can let the stop callback handle clearing state.
		if (!$client->isStopped()) {
			ClearClientPlaybackState($client);
		}
	}
}

##############################################
#
#  Menu Construction
#
##############################################

sub _RootMenu {
    my ($client, $callback, $params, $args) = @_;

    if (!Plugins::Sprocket::Settings::AuthToken()) {
		$callback->([
			{
				name => cstring($client, 'PLUGIN_SPROCKET_NEEDS_LOGIN'),
				type => 'textarea',
			},
		]);
    	return;
    }

    $callback->([
		{
			name => cstring($client, 'PLUGIN_SPROCKET_UP_NEXT'),
			type => 'playlist',
			url => \&_UpNextPlaylistMenu,
		},
		{
			name => cstring($client, 'PLUGIN_SPROCKET_NEW_RELEASES'),
			type => 'playlist',
			url => \&_NewReleasesPlaylistMenu,
		},
		{
			name => cstring($client, 'PLUGIN_SPROCKET_IN_PROGRESS'),
			type => 'playlist',
			url => \&_InProgressPlaylistMenu,
		},
		{
			name => cstring($client, 'PLUGIN_SPROCKET_STARRED'),
			type => 'playlist',
			url => \&_StarredPlaylistMenu,
		},
		{
			name => cstring($client, 'PLUGIN_SPROCKET_SUBSCRIPTIONS'),
			type => 'link',
			url => \&_SubscriptionMenu,
		},
    ]);
}

sub _PlaylistMenuItemFromEpisodes {
	my ($episodes, $playall) = @_;

	my @items = ();
	foreach my $episode (@{$episodes}) {
		my $handlerURL = Plugins::Sprocket::URL::HandlerURLForEpisode($episode);
		if (!$handlerURL) {
			next;
		}

		my $item = {
			play => $handlerURL,
			on_select => 'play',
			favorites => 0,  # Suppress favorites, haven't found a way to map to starring.
		};
		if ($playall) {
			$item->{playall} = 1;
		}
		$item->{name} = $episode->{'title'};
		$item->{line1} = $episode->{'title'};
		if ($episode->{'podcastTitle'}) {
			if ($episode->{'title'} !~ /^\Q$episode->{'podcastTitle'}\E/) {
				$item->{name} .= " - " . $episode->{'podcastTitle'};
			}
			$item->{line2} = $episode->{'podcastTitle'};
		}
		my $iconURL = Plugins::Sprocket::URL::ProxiedImageURL(Plugins::Sprocket::API::EpisodeIconURL($episode));
		if ($iconURL) {
			$item->{image} = $iconURL;
		}

		push(@items, $item);
	}

	return {
		items => \@items,
	};
}

sub _UpNextPlaylistMenu {
    my ($client, $callback, $params, $args) = @_;

    Plugins::Sprocket::API::UpNextEpisodes(sub {
    	my ($episodes) = @_;

		if ($episodes) {
			if (scalar(@{$episodes})) {
				$callback->(_PlaylistMenuItemFromEpisodes($episodes, 1));
			} else {
				$callback->([
					{
						name => cstring($client, 'PLUGIN_SPROCKET_UP_NEXT_EMPTY'),
						type => 'textarea',
					},
				]);
			}
		} else {
    		$callback->([
				{
					name => cstring($client, 'PLUGIN_SPROCKET_UP_NEXT_FAILURE'),
					type => 'textarea',
				},
    		]);
		}
    });
}

sub _StarredPlaylistMenu {
    my ($client, $callback, $params, $args) = @_;

    Plugins::Sprocket::API::StarredEpisodes(sub {
    	my ($episodes) = @_;

		if ($episodes) {
			if (scalar(@{$episodes})) {
				$callback->(_PlaylistMenuItemFromEpisodes($episodes, 0));
			} else {
				$callback->([
					{
						name => cstring($client, 'PLUGIN_SPROCKET_STARRED_EMPTY'),
						type => 'textarea',
					},
				]);
			}
		} else {
    		$callback->([
				{
					name => cstring($client, 'PLUGIN_SPROCKET_STARRED_FAILURE'),
					type => 'textarea',
				},
    		]);
		}
    });
}

sub _NewReleasesPlaylistMenu {
    my ($client, $callback, $params, $args) = @_;

    Plugins::Sprocket::API::NewReleaseEpisodes(sub {
    	my ($episodes) = @_;

		if ($episodes) {
			if (scalar(@{$episodes})) {
				$callback->(_PlaylistMenuItemFromEpisodes($episodes, 0));
			} else {
				$callback->([
					{
						name => cstring($client, 'PLUGIN_SPROCKET_NEW_RELEASES_EMPTY'),
						type => 'textarea',
					},
				]);
			}
		} else {
    		$callback->([
				{
					name => cstring($client, 'PLUGIN_SPROCKET_NEW_RELEASES_FAILURE'),
					type => 'textarea',
				},
    		]);
		}
    });
}

sub _InProgressPlaylistMenu {
    my ($client, $callback, $params, $args) = @_;

    Plugins::Sprocket::API::InProgressEpisodes(sub {
    	my ($episodes) = @_;

		if ($episodes) {
			if (scalar(@{$episodes})) {
				$callback->(_PlaylistMenuItemFromEpisodes($episodes, 0));
			} else {
				$callback->([
					{
						name => cstring($client, 'PLUGIN_SPROCKET_IN_PROGRESS_EMPTY'),
						type => 'textarea',
					},
				]);
			}
		} else {
    		$callback->([
				{
					name => cstring($client, 'PLUGIN_SPROCKET_IN_PROGRESS_FAILURE'),
					type => 'textarea',
				},
    		]);
		}
    });
}

sub _SubscriptionMenu {
    my ($client, $callback, $params, $args) = @_;

    Plugins::Sprocket::API::Subscriptions(sub {
    	my ($subscriptions) = @_;

    	if ($subscriptions) {
    		if (scalar(@{$subscriptions}) > 0) {
    			_SubscriptionMenuItems($client, $callback, $subscriptions);
    		} else {
				$callback->([
					{
						name => cstring($client, 'PLUGIN_SPROCKET_NO_SUBSCRIPTIONS'),
						type => 'textarea',
					},
				]);
    		}
    	} else {
    		$callback->([
				{
					name => cstring($client, 'PLUGIN_SPROCKET_SUBSCRIPTION_FAILURE'),
					type => 'textarea',
				},
    		]);
    	}
    });
}

sub _SubscriptionMenuItems {
	my ($client, $callback, $subscriptions) = @_;

	my @sortedSubs = sort(
		{ _SortableTitle($a->{'title'}) cmp _SortableTitle($b->{'title'}) } @{$subscriptions}
	);

	my @menuItems = ();
	foreach my $podcast (@sortedSubs) {
		my $title =  $podcast->{'title'};
		if ($podcast->{'unplayed'}) {
			$title .= " " . UNICODE_BULLET;
		}
		my $menuItem = {
			name => $title,
			type => 'link',
			url => \&_SubscriptionItemMenu,
			passthrough => [{
				podcast => $podcast,
			}],
		};
		my $iconURL = Plugins::Sprocket::URL::ProxiedImageURL(Plugins::Sprocket::API::PodcastIconURL($podcast));
		if ($iconURL) {
			$menuItem->{image} = $iconURL;
		}

		push(@menuItems, $menuItem);
	}
	$callback->(\@menuItems);
}


sub _SubscriptionItemMenu {
    my ($client, $callback, $params, $args) = @_;

    my $podcast = $args->{podcast};
    if (!$podcast) {
		$log->error("Cannot locate podcast passthrough.");
		$callback->([
			{
				name => cstring($client, 'PLUGIN_SPROCKET_PODCAST_LIST_FAILURE'),
				type => 'textarea',
			},
		]);
		return;
    }

    my $name = cstring($client, 'PLUGIN_SPROCKET_SUBSCRIPTION_UNLISTENED_EPISODES');
	if ($podcast->{'unplayed'}) {
		$name .= " " . UNICODE_BULLET;
	}

    $callback->([
		{
			name => $name,
			type => 'link',
			url => \&_SubscriptionUnlistenedEpisodesItemMenu,
			passthrough => [{
				podcast => $podcast,
			}],
		},
		{
			name => cstring($client, 'PLUGIN_SPROCKET_SUBSCRIPTION_ALL_EPISODES'),
			type => 'link',
			url => \&_SubscriptionAllEpisodesItemMenu,
			passthrough => [{
				podcast => $podcast,
			}],
		},
    ]);
}

sub _SubscriptionUnlistenedEpisodesItemMenu {
    my ($client, $callback, $params, $args) = @_;

    my $podcast = $args->{podcast};
    if (!$podcast) {
		$log->error("Cannot locate podcast passthrough.");
		$callback->([
			{
				name => cstring($client, 'PLUGIN_SPROCKET_PODCAST_LIST_FAILURE'),
				type => 'textarea',
			},
		]);
		return;
    }

    Plugins::Sprocket::API::EpisodesForPodcast($podcast, sub {
    	my ($episodes) = @_;

    	if (Plugins::Sprocket::Settings::BrowseEpisodeSort() != Plugins::Sprocket::API::EpisodeSortDescending) {
    		@{$episodes} = reverse(@{$episodes});
    	}

    	my $filterFunction = sub {
    		my ($episode) = @_;
			if ($episode->{'isDeleted'}) {
				return 0;
			}
			if ($episode->{'playingStatus'} == Plugins::Sprocket::API::PlayStatusPlayed) {
				return 0;
			}
			return 1;
		};

    	my @filtered = grep{ $filterFunction->($_) } @{$episodes};
    	$episodes = \@filtered;

		if ($episodes) {
			if (scalar(@{$episodes})) {
				$callback->(_PlaylistMenuItemFromEpisodes($episodes, 0));
			} else {
				$callback->([
					{
						name => cstring($client, 'PLUGIN_SPROCKET_NO_UNLISTENED_EPISODES'),
						type => 'textarea',
					},
				]);
			}
		} else {
    		$callback->([
				{
					name => cstring($client, 'PLUGIN_SPROCKET_PODCAST_LIST_FAILURE'),
					type => 'textarea',
				},
    		]);
		}
    });
}

sub _SubscriptionAllEpisodesItemMenu {
    my ($client, $callback, $params, $args) = @_;

    my $podcast = $args->{podcast};
    if (!$podcast) {
		$log->error("Cannot locate podcast passthrough.");
		$callback->([
			{
				name => cstring($client, 'PLUGIN_SPROCKET_PODCAST_LIST_FAILURE'),
				type => 'textarea',
			},
		]);
		return;
    }

    Plugins::Sprocket::API::EpisodesForPodcast($podcast, sub {
    	my ($episodes) = @_;

    	if (Plugins::Sprocket::Settings::BrowseEpisodeSort() != Plugins::Sprocket::API::EpisodeSortDescending) {
    		@{$episodes} = reverse(@{$episodes});
    	}

		if ($episodes) {
			if (scalar(@{$episodes})) {
				$callback->(_PlaylistMenuItemFromEpisodes($episodes, 0));
			} else {
				$callback->([
					{
						name => cstring($client, 'PLUGIN_SPROCKET_NO_EPISODES'),
						type => 'textarea',
					},
				]);
			}
		} else {
    		$callback->([
				{
					name => cstring($client, 'PLUGIN_SPROCKET_PODCAST_LIST_FAILURE'),
					type => 'textarea',
				},
    		]);
		}
    });
}

##############################################
#
#  Utility
#
##############################################

sub _SortableTitle {
	my ($title) = @_;

	return Slim::Utils::Text::ignoreCaseArticles($title);
}

1;
