# Copyright (c) 2019 Alex Harper
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are
# met:
#
#     (1) Redistributions of source code must retain the above copyright
#     notice, this list of conditions and the following disclaimer.
#
#     (2) Redistributions in binary form must reproduce the above copyright
#     notice, this list of conditions and the following disclaimer in
#     the documentation and/or other materials provided with the
#     distribution.
#
#     (3)The name of the author may not be used to
#     endorse or promote products derived from this software without
#     specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
# IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
# WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
# DISCLAIMED. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT,
# INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
# (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
# SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
# HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
# STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
# IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
# POSSIBILITY OF SUCH DAMAGE.

package Plugins::Sprocket::ProtocolHandler;

use strict;
use Symbol;

use Slim::Control::Request;
use Slim::Music::Info;
use Slim::Player::Pipeline;
use Slim::Player::Protocols::HTTP;
use Slim::Player::TranscodingHelper;
use Slim::Utils::Log;
use Slim::Utils::Scanner::Remote;
use Slim::Utils::Prefs;

use Plugins::Sprocket::API;
use Plugins::Sprocket::Cache;
use Plugins::Sprocket::Plugin;
use Plugins::Sprocket::Protocols::HTTPS;
use Plugins::Sprocket::URL;
use Plugins::Sprocket::Settings;

my $log = logger('plugin.sprocket');

sub new {
	my ($class, $args) = @_;

	my $client = $args->{client};
	my $song = $args->{song};

	# Player (epecially Song.pm) needs us to be an glob even if we are composition, not inheritance.
	my $self = gensym();
	bless($self, $class);
	if (!$self) {
		return undef();
	}

	my $episode = $song->pluginData('episode');
	if (!$episode) {
		$log->error("Missing episode information from song.");
		return undef();
	}

	my $finalURL = $song->pluginData('scannedURL');
	if (!$finalURL) {
		$finalURL = $episode->{'url'};
	}
	if (!$finalURL) {
		$log->error("Missing real episode URL.");
		return undef();
	}

	my $playbackSpeed = $song->pluginData('playbackSpeed');
	if (!$playbackSpeed) {
		$log->error("Missing playback speed.");
		return undef();
	}

	# Build the HTTP protocol handler we use to stream the original source.
	my $httpHandler = undef();
	if ($finalURL =~ /^http:/) {
		$log->info("Opening HTTP protocol handler for $finalURL.");
		$httpHandler = Slim::Player::Protocols::HTTP->new({
			url => $finalURL,
			song => $song,
			client => $client,
		});
	} elsif ($finalURL =~ /^https:/) {
		$log->info("Opening HTTPS protocol handler for $finalURL.");
		$httpHandler = Plugins::Sprocket::Protocols::HTTPS->new({
			url => $finalURL,
			song => $song,
			client => $client,
		});
	} else {
		$log->error("Unknown URL scheme.");
	}
	if (!$httpHandler) {
		$log->error("Failed to get HTTP/HTTPS handler.");
		return undef();
	}

	# Song.pm will eventually want things in binmode, so just do that.
	binmode($httpHandler);

	# Build the pipeline we use for variable speed.
	my $transcoderContentType = "sprocketmp3";  # A reasonable guess.
	my $sourceContentType = $song->pluginData('scannedContentType');
	if ($sourceContentType) {
		$transcoderContentType = "sprocket" . $sourceContentType;
	}

	my $transcoder = Slim::Player::TranscodingHelper::getConvertCommand2(
		$song,
		$transcoderContentType,
		['I'],  # Has to work in a pipeline.
		[], [],  # No wants or needs.
		"pcm"  # Force PCM output.
	);
	if (!$transcoder) {
		$log->error("Failed to get transcoder.");
		return undef();
	}

	my $transcodeCommand = Slim::Player::TranscodingHelper::tokenizeConvertCommand2(
		$transcoder,
		'-', # Using a pipe
		'',  # Don't actually need this in our command.
		1,  # Using a pipe
		''  # Not transcoding to mp3, so quality arg is unused.
	);
	if (!$transcodeCommand) {
		$log->error("Failed to get transcoder command.");
		return undef();
	}

	# Replace tempo placeholder in command,
	my $tempoString = sprintf('%0.1f', Plugins::Sprocket::Settings::PlaybackSpeed());
	$transcodeCommand =~ s/PLAYBACKSPEED/$tempoString/;

	my $transcodePipe = Slim::Player::Pipeline->new(
		$httpHandler,
		$transcodeCommand,
		0  # Not local.
	);
	if (!$transcodePipe) {
		$log->error("Failed to get transcoder pipeline.");
		return undef();
	}

	# Weird ivar access because we are a glob.
	${*$self}{httpHandler} = $httpHandler;
	${*$self}{transcodePipe} = $transcodePipe;
	${*$self}{episode} = $episode;
	${*$self}{scannedContentType} = $song->pluginData('scannedContentType');
	if (!${*$self}{scannedContentType}) {
		${*$self}{scannedContentType} = Slim::Music::Info::mimeToType($episode->{'fileType'});
	}

	# Add episode data to client if it's the master.
	if (!$client->isSynced() || ($client->isSynced() && Slim::Player::Sync::isMaster($client))) {
		$client->pluginData( episode => $episode );
		$client->pluginData( playbackSpeed => $playbackSpeed );
	} else {
		Plugins::Sprocket::Plugin::ClearClientPlaybackState($client);
	}

	return $self;
}

sub DESTROY {
	# No particular cleanup here.
}

sub isRemote {
	return 1;
}

sub canDirectStream {
	return 0;  # Server handles speed adjustments.
}

sub contentType {
	my ($self) = @_;
	return 'pcm';
}

sub audioScrobblerSource {
	# No scrobbling
	return undef();
}

sub getFormatForURL {
	my ($classOrSelf, $url) = @_;
	return 'pcm';
}

sub scanUrl {
	# This is called as a class method pre-new().
	my ($class, $url, $args) = @_;

	my $callback = $args->{cb};
	my $song = $args->{song};

	if (!$song) {
		$log->error("No song for private URL: " . $url);
		$callback->();
		return;
	}

	my $uuid = Plugins::Sprocket::URL::EpisodeUUIDFromHandlerURL($url);
	if (!$uuid) {
		$log->error("Could not parse private URL: " . $url);
		$callback->();
		return;
	}

	Plugins::Sprocket::API::EpisodeFromUUID($uuid, sub {
		my ($episode) = @_;

		if (!$episode) {
			$log->error("No episode for private URL: " . $url);
			$callback->();
			return;
		}

		$song->pluginData( episode => $episode );

		my $realURL = $episode->{'url'};
		if (!$realURL) {
			$log->error("No real URL for private URL: " . $url);
			$callback->();
			return;
		}

		# This callback function takes a scanned track from a URL and fixes it up so it
		# uses our metadata and the original URL.
		my $scannedTrackCallback = sub {
			my ($scannedTrack) = @_;

			# Stash the final redirected URL.
			$song->pluginData( scannedURL => $scannedTrack->url() );

			# Stash the final bitrate for seeking.
			$song->pluginData( scannedBitrate => $scannedTrack->bitrate() );

			# Stash the content type if the scanner figured it out.
			if ($scannedTrack->content_type()) {
				$song->pluginData( scannedContentType => $scannedTrack->content_type() );
			} else {
				my $allData = $song->pluginData();
				delete($allData->{scannedContentType});
			}

			# Restore our original URL. This is critical to not introducing another
			# protocol handler.
			$scannedTrack->url($url);

			# Get the current speed and stash it, subsequent data is based on this.
			my $playbackSpeed = Plugins::Sprocket::Settings::PlaybackSpeed();
			$song->pluginData( playbackSpeed => $playbackSpeed );

			# Adjust duration for playback speed.
			my $duration = $scannedTrack->secs();
			# Favor duration from the server if there is one.
			if ($episode->{'duration'}) {
				$duration = $episode->{'duration'};
			}
			$scannedTrack->secs(int($duration / $playbackSpeed));

			# Fields we set arbitrarily.
			$scannedTrack->title($episode->{'title'});
			if ($episode->{'podcastTitle'}) {
				$scannedTrack->album($episode->{'podcastTitle'});
			}

			# Force the apparent type to be PCM.
			$scannedTrack->content_type('pcm');
			$scannedTrack->bitrate(44100 * 16 * 2);
			$scannedTrack->vbr_scale(undef());

			$scannedTrack->update();

			$callback->($scannedTrack);
		};

		# Overwrite the original callback with our own so we can see and modify the result.
		$args->{cb} = $scannedTrackCallback;

		# Scan the real URL. This would recurse if we implemented scanStream(), but we do not.
		Slim::Utils::Scanner::Remote->scanURL($realURL, $args);
	});
}

sub getMetadataFor {
	my ($class, $client, $url, $forceCurrent) = @_;

	my $uuid = Plugins::Sprocket::URL::EpisodeUUIDFromHandlerURL($url);
	if (!$uuid) {
		$log->error("Could not parse private URL: " . $url);
		return undef();
	}

	# Episode may already be set on this client.
	my $episode = $client->pluginData('episode');
	if (!$episode || ($episode->{'uuid'} ne $uuid)) {
		# If not on client, service from cache.
		$episode = Plugins::Sprocket::Cache::GetCachedEpisodeForUUID($uuid);
		if (!$episode) {
			Plugins::Sprocket::API::EpisodeFromUUID($uuid, sub {
				# We don't actually care about the episode here, we're just seeding the cache.
				if ($client) {
					Slim::Control::Request::notifyFromArray($client, [ 'newmetadata' ]);
				}
			});
			return undef();
		}
	}

	my $meta = {
		title => $episode->{'title'},
		type => 'pcm',
		bitrate => '1378kbps CBR',
	};
	if ($episode->{'podcastTitle'}) {
		$meta->{album} = $episode->{'podcastTitle'};
	}
	my $playbackSpeed = $client->pluginData('playbackSpeed');
	if ($episode->{'duration'} && $playbackSpeed) {
		$meta->{duration} = int($episode->{'duration'} / $playbackSpeed);
	}

	my $iconURL = Plugins::Sprocket::URL::ProxiedImageURL(Plugins::Sprocket::API::EpisodeIconURL($episode));
	if ($iconURL) {
		$meta->{icon} = $iconURL;
		$meta->{cover} = $iconURL;
	}

	return $meta;
}

sub canSeek {
	my ($class, $client, $song) = @_;

	my $httpHandlerCanSeek = Slim::Player::Protocols::HTTP->canSeek($client, $song);
	return $httpHandlerCanSeek;
}

sub canSeekError {
	my ($class, $client, $song) = @_;

	return Slim::Player::Protocols::HTTP->canSeekError($client, $song);
}

sub getSeekData {
	my ($class, $client, $song, $newtime) = @_;

	my $realBitrate = $song->pluginData('scannedBitrate');
	if (!$realBitrate) {
		return undef();
	}
	my $playbackSpeed = $song->pluginData('playbackSpeed');
	if (!$playbackSpeed) {
		return undef();
	}

	# We have to save/restore the bitrate.
	my $restoreBitrate = $song->bitrate();
	$song->bitrate($realBitrate);

	# Adjust time based on playback speed.
	my $adjustedTime = int($newtime * $playbackSpeed);

	$log->debug("Seeking to $adjustedTime ($newtime x $playbackSpeed).");

	my $httpHandlerSeekData = Slim::Player::Protocols::HTTP->getSeekData($client, $song, $adjustedTime);

	$httpHandlerSeekData->{'timeOffset'} = $newtime;
	$song->bitrate($restoreBitrate);

	return $httpHandlerSeekData;
}

sub getSeekDataByPosition {
	my ($class, $client, $song, $bytesReceived) = @_;

	# Because we don't map the data 1:1 we don't support byte offset seeks.
	return undef();
}

##############################################
#
#  IO::Handle
#
#  TODO: What other parts of IO::Handle are needed? This set seems to work.
#
##############################################

sub opened {
	my ($self) = @_;
	return ${*$self}{httpHandler}->opened() && ${*$self}{transcodePipe}->opened();
}

sub blocking {
	my ($self, $mode) = @_;
	# There's no quite correct version of combining these two handle states. The good
	# news is that this method is really only used to set state.
	my $httpHandlerResult = ${*$self}{httpHandler}->blocking($mode);
	my $transcodePipeResult = ${*$self}{transcodePipe}->blocking($mode);
	return ($httpHandlerResult xor $transcodePipeResult);
}

sub sysread {
	my ($self, undef, $chunkSize) = @_;

	# We read directly from the pipe. Note that the direct ref to the function argument here
	# is needed. If we assign it to a local we get a copy.
	return ${*$self}{transcodePipe}->sysread($_[1], $chunkSize);
}

sub close {
	my ($self) = @_;
	# We'll allow the pipe to close the http handler first.
	my $transcodePipeResult = ${*$self}{transcodePipe}->close();
	# Just to be sure.
	${*$self}{httpHandler}->close();
	return $transcodePipeResult;
}

1;