# Copyright (c) 2019 Alex Harper
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are
# met:
#
#     (1) Redistributions of source code must retain the above copyright
#     notice, this list of conditions and the following disclaimer.
#
#     (2) Redistributions in binary form must reproduce the above copyright
#     notice, this list of conditions and the following disclaimer in
#     the documentation and/or other materials provided with the
#     distribution.
#
#     (3)The name of the author may not be used to
#     endorse or promote products derived from this software without
#     specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
# IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
# WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
# DISCLAIMED. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT,
# INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
# (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
# SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
# HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
# STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
# IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
# POSSIBILITY OF SUCH DAMAGE.

package Plugins::Sprocket::Cache;

use strict;
use warnings;

use Storable;
use Time::HiRes;

use Slim::Utils::Log;

my $log = logger('plugin.sprocket');


my $subscriptionsCache = undef();
my $subscriptionsCacheExpire = undef();

sub GetCachedSubscriptions {
	my $now = Time::HiRes::time();
	_ScrubCache($now);

	if (defined($subscriptionsCache)) {
		return Storable::dclone($subscriptionsCache);
	} else {
		return undef();
	}
}

sub SetCachedSubscriptions {
	my ($subs, $timeout) = @_;

	my $now = Time::HiRes::time();
	_ScrubCache($now);

	if (!$subs) {
		return;
	}

	$subscriptionsCache = Storable::dclone($subs);
	$subscriptionsCacheExpire = $now + $timeout;
}

sub InvalidateSubscriptionsCache {
	$log->debug("Invalidating Subscriptions cache.");
	$subscriptionsCache = undef();
	$subscriptionsCacheExpire = undef();
}


my $upNextEpisodeUUIDsCache = undef();
my $upNextCacheExpire = undef();

sub GetCachedUpNextEpisodeUUIDs {
	my $now = Time::HiRes::time();
	_ScrubCache($now);

	if (defined($upNextEpisodeUUIDsCache)) {
		return Storable::dclone($upNextEpisodeUUIDsCache);
	} else {
		return undef();
	}
}

sub SetCachedUpNextEpisodeUUIDs {
	my ($uuids, $timeout) = @_;

	my $now = Time::HiRes::time();
	_ScrubCache($now);

	if (!$uuids) {
		return;
	}

	$upNextEpisodeUUIDsCache = Storable::dclone($uuids);
	$upNextCacheExpire = $now + $timeout;
}

sub InvalidateUpNextCachedEpisodeUUIDs {
	$log->debug("Invalidating Up Next cache.");
	$upNextEpisodeUUIDsCache = undef();
	$upNextCacheExpire = undef();
}


my $newReleaseEpisodesCache = undef();
my $newReleaseCacheExpire = undef();

sub GetCachedNewReleaseEpisodes {
	my $now = Time::HiRes::time();
	_ScrubCache($now);

	if (defined($newReleaseEpisodesCache)) {
		return Storable::dclone($newReleaseEpisodesCache);
	} else {
		return undef();
	}
}

sub SetCachedNewReleaseEpisodes {
	my ($episodes, $timeout) = @_;

	my $now = Time::HiRes::time();
	_ScrubCache($now);

	if (!$episodes) {
		return;
	}

	$newReleaseEpisodesCache = Storable::dclone($episodes);
	$newReleaseCacheExpire = $now + $timeout;
}

sub InvalidateNewReleaseCachedEpisodes {
	$log->debug("Invalidating New Release cache.");
	$newReleaseEpisodesCache = undef();
	$newReleaseCacheExpire = undef();
}


my $inProgressEpisodeUUIDsCache = undef();
my $inProgressCacheExpire = undef();

sub GetCachedInProgressEpisodeUUIDs {
	my $now = Time::HiRes::time();
	_ScrubCache($now);

	if (defined($inProgressEpisodeUUIDsCache)) {
		return Storable::dclone($inProgressEpisodeUUIDsCache);
	} else {
		return undef();
	}
}

sub SetCachedInProgressEpisodeUUIDs {
	my ($uuids, $timeout) = @_;

	my $now = Time::HiRes::time();
	_ScrubCache($now);

	if (!$uuids) {
		return;
	}

	$inProgressEpisodeUUIDsCache = Storable::dclone($uuids);
	$inProgressCacheExpire = $now + $timeout;
}

sub InvalidateInProgressCachedEpisodeUUIDs {
	$log->debug("Invalidating In Progress cache.");
	$inProgressEpisodeUUIDsCache = undef();
	$inProgressCacheExpire = undef();
}


my $starredEpisodeUUIDsCache = undef();
my $starredCacheExpire = undef();

sub GetCachedStarredEpisodeUUIDs {
	my $now = Time::HiRes::time();
	_ScrubCache($now);

	if (defined($starredEpisodeUUIDsCache)) {
		return Storable::dclone($starredEpisodeUUIDsCache);
	} else {
		return undef();
	}
}

sub SetCachedStarredEpisodeUUIDs {
	my ($uuids, $timeout) = @_;

	my $now = Time::HiRes::time();
	_ScrubCache($now);

	if (!$uuids) {
		return;
	}

	$starredEpisodeUUIDsCache = Storable::dclone($uuids);
	$starredCacheExpire = $now + $timeout;
}

sub InvalidateStarredCachedEpisodeUUIDs {
	$log->debug("Invalidating Starred cache.");
	$starredEpisodeUUIDsCache = undef();
	$starredCacheExpire = undef();
}


my $episodeCache = {};

sub GetCachedEpisodeForUUID {
	my ($uuid) = @_;

	my $now = Time::HiRes::time();
	_ScrubCache($now);

	if (!$uuid) {
		return undef();
	}

	my $cacheRecord = $episodeCache->{$uuid};
	if (!$cacheRecord) {
		return undef();
	}
	return Storable::dclone($cacheRecord->{episode});
}

sub SetCachedEpisode {
	my ($episode, $timeout) = @_;

	my $now = Time::HiRes::time();
	_ScrubCache($now);

	if (!$episode->{'uuid'}) {
		return;
	}

	$episodeCache->{$episode->{'uuid'}} = {
		expire => $now + $timeout,
		episode => Storable::dclone($episode),
	}
}

sub InvalidateCachedEpisode {
	my ($episode) = @_;

	my $now = Time::HiRes::time();
	 _ScrubCache($now);

	if (!$episode->{'uuid'}) {
		return;
	}

  delete($episodeCache->{$episode->{'uuid'}});
}


my $unpersonalizedPodcastCache = {};

sub GetCachedUnpersonalizedEpisodesForPodcast {
	my ($podcast) = @_;

	my $now = Time::HiRes::time();
	_ScrubCache($now);

	if (!$podcast->{'uuid'}) {
		return undef();
	}

	my $cacheRecord = $unpersonalizedPodcastCache->{$podcast->{'uuid'}};
	if (!$cacheRecord) {
		return undef();
	}

	return Storable::dclone($cacheRecord->{episodes});
}

sub SetCacheUnpersonalizedEpisodesForPodcast {
	my ($podcast, $unpersonalizedEpisodes, $timeout) = @_;

	my $now = Time::HiRes::time();
	_ScrubCache($now);

	if (!$podcast->{'uuid'}) {
		return;
	}

	$unpersonalizedPodcastCache->{$podcast->{'uuid'}} = {
		expire => $now + $timeout,
		episodes => Storable::dclone($unpersonalizedEpisodes),
	}
}

##############################################
#
#  Utility
#
##############################################

sub _ScrubCache {
	my ($now) = @_;

	if (!defined($now)) {
	  $now = Time::HiRes::time();
	}

	if (defined($subscriptionsCacheExpire) && ($subscriptionsCacheExpire < $now)) {
		InvalidateSubscriptionsCache();
	}

	if (defined($upNextCacheExpire) && ($upNextCacheExpire < $now)) {
		InvalidateUpNextCachedEpisodeUUIDs();
	}

	if (defined($newReleaseCacheExpire) && ($newReleaseCacheExpire < $now)) {
		InvalidateNewReleaseCachedEpisodes();
	}

	if (defined($inProgressCacheExpire) && ($inProgressCacheExpire < $now)) {
		InvalidateInProgressCachedEpisodeUUIDs();
	}

	if (defined($starredCacheExpire) && ($starredCacheExpire < $now)) {
		InvalidateStarredCachedEpisodeUUIDs();
	}

	foreach my $uuid (keys(%{$episodeCache})) {
		my $cacheRecord = $episodeCache->{$uuid};
		if (!$cacheRecord) {
			next;
		}
		if ($cacheRecord->{expire} < $now) {
			delete($episodeCache->{$uuid});
		}
	}

	foreach my $uuid (keys(%{$unpersonalizedPodcastCache})) {
		my $cacheRecord = $unpersonalizedPodcastCache->{$uuid};
		if (!$cacheRecord) {
			next;
		}
		if ($cacheRecord->{expire} < $now) {
			delete($unpersonalizedPodcastCache->{$uuid});
		}
	}
}

1;
