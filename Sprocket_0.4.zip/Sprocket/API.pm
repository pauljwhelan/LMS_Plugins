# Copyright (c) 2019 Alex Harper
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are
# met:
#
#     (1) Redistributions of source code must retain the above copyright
#     notice, this list of conditions and the following disclaimer.
#
#     (2) Redistributions in binary form must reproduce the above copyright
#     notice, this list of conditions and the following disclaimer in
#     the documentation and/or other materials provided with the
#     distribution.
#
#     (3)The name of the author may not be used to
#     endorse or promote products derived from this software without
#     specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
# IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
# WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
# DISCLAIMED. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT,
# INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
# (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
# SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
# HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
# STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
# IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
# POSSIBILITY OF SUCH DAMAGE.


package Plugins::Sprocket::API;

# API details consolidated from various sources and examples:
#
# https://github.com/atehnix/pocketcasts-client
# https://github.com/zackbcom/python-pocketcasts
# https://github.com/sirl1on/python-pocketcasts
# https://github.com/B-Lach/PocketCastsKit
# https://github.com/donatj/pocketcasts-go
# https://github.com/furgoose/Pocket-Casts

use strict;

use Compress::Raw::Zlib;
use Data::Dumper;
use IO::Socket::SSL;
use JSON::XS::VersionOneAndTwo;
use HTTP::Headers;
use HTTP::Request;
use LWP::UserAgent;
use Time::HiRes;

use Slim::Networking::SimpleAsyncHTTP;
use Slim::Utils::Log;
use Slim::Utils::Prefs;
use Slim::Utils::Timers;

use Plugins::Sprocket::Cache;


my $log = logger('plugin.sprocket');
my $prefs = preferences('plugin.sprocket');


# Constants
use constant PlayStatusUnplayed => 0;
use constant PlayStatusPlaying => 2;
use constant PlayStatusPlayed => 3;
use constant EpisodeSortAscending => 2;
use constant EpisodeSortDescending => 3;


sub _GetAPIToken {
	# Have to use prefs directly to avoid cyclic includes.
	return  $prefs->get('authToken') ? $prefs->get('authToken') : undef();
}

sub DoSyncLogin {
	my ($username, $password) = @_;
	if (!($username && $password)) {
		return undef();
	}

	my $loginRequestJSON = {
		"email" => $username,
		"password" => $password,
		"scope" => "webplayer"
	};

	my $ua = LWP::UserAgent->new(
		timeout => 20,
		ssl_opts => {
			verify_hostname => 0,
			SSL_verify_mode => IO::Socket::SSL::SSL_VERIFY_NONE
		},
	);

	my $loginRequest = HTTP::Request->new("POST", "https://api.pocketcasts.com/user/login");
	$loginRequest->content(encode_json($loginRequestJSON));

	my $loginResponse = $ua->request($loginRequest);

	if ($loginResponse->is_error) {
		$log->error("Login response indicates error.");
		return undef();
	}

	my $loginResponseJSON = decode_json($loginResponse->content);

	if (!$loginResponseJSON->{"token"}) {
		$log->error("Login response missing access token.");
		return undef();
	}

	return $loginResponseJSON->{"token"};
}

# Helper for ensuring that early return calls are async just like network calls.
sub _DoAsyncEarlyReturn {
	my ($callback) = @_;

	if (!$callback) {
		return;
	}

	Slim::Utils::Timers::setTimer(undef(), Time::HiRes::time() + 0.5, $callback);
}

# We might consider serializing API requests so that out of order requests don't cause cache issues.
sub _GetAPIResponse {
	my ($url, $payload, $callback) = @_;

	my $token = _GetAPIToken();
	if (!$token) {
		$log->error("Unable to obtain API token.");
		_DoAsyncEarlyReturn(sub {
			$callback->();
		});
		return;
	}

	Slim::Networking::SimpleAsyncHTTP->new(
		# Success
		sub {
			my ($response) = @_;
			my $result = eval { from_json($response->content) };
			$callback->($result);
		},
		# Error
		sub {
			my ($http, $error) = @_;
			$log->error("API response error: $error");
			$callback->();
		},
		# Parameters
		{
			timeout => 15,
		},
	)->post(
		$url,
		(
			'Authorization' => 'Bearer ' . $token,
			'Content-Type' => 'application/json',
			'Origin' => 'https://play.pocketcasts.com',
			'Referer' => 'https://play.pocketcasts.com/podcasts',
		),
		defined($payload) ? to_json($payload) : undef
	);
}

sub EpisodeFromUUID {
	my ($uuid, $callback) = @_;

	if (!$uuid) {
		$log->error("Cannot get episode without UUID.");
		_DoAsyncEarlyReturn(sub {
			$callback->();
		});
		return;
	}

	my $cached = Plugins::Sprocket::Cache::GetCachedEpisodeForUUID($uuid);
	if ($cached) {
		_DoAsyncEarlyReturn(sub {
			$callback->($cached);
		});
		return;
	}

	_GetAPIResponse(
		'https://api.pocketcasts.com/user/episode',
		{ "uuid" => $uuid },
		sub {
			my ($response) = @_;
			if (_IsValidEpisode($response)) {
				# Cache for the length of the episode at least.
				my $timeout = $response->{'duration'};
				if (!$timeout) {
					$timeout = 600;	 # Best we can do.
				}
				Plugins::Sprocket::Cache::SetCachedEpisode($response, $timeout);

				$callback->($response);
			} else {
				$log->error("Received invalid episode response.");
				$callback->();
			}
		}
	);
}

sub _EpisodeUUIDInflateHelper {
	my ($episodeUUIDs, $finalCallback) = @_;

	if (!scalar(@{$episodeUUIDs})) {
		_DoAsyncEarlyReturn(sub {
			# Empty list here means empty, not error.
			$finalCallback->([]);
		});
		return;
	}

	my @episodes = ();
	my $episodeCallBack = undef();  # Swapped with temp before use.
	my $tempCallback = sub {
		my ($episode) = @_;
		if ($episode) {
			push(@episodes, $episode);
		}
		my $nextUUID = shift(@{$episodeUUIDs});
		if ($nextUUID) {
			EpisodeFromUUID($nextUUID, $episodeCallBack);
		} else {
			$finalCallback->(\@episodes);
		}
	};
	$episodeCallBack = $tempCallback;
	EpisodeFromUUID(shift(@{$episodeUUIDs}), $episodeCallBack);
}

sub UpNextEpisodes {
	my ($callback) = @_;

	my $cachedUUIDs = Plugins::Sprocket::Cache::GetCachedUpNextEpisodeUUIDs();
	if (defined($cachedUUIDs)) {
		$log->debug("Using cached Up Next episodes.");
		# Turn the UUIDs into episodes.
		_EpisodeUUIDInflateHelper($cachedUUIDs, $callback);
		return;
	}

	$log->debug("Getting Up Next episodes.");
	_GetAPIResponse(
		'https://api.pocketcasts.com/up_next/list',
		{ "version" => 2, "model" => "webplayer", "serverModified" => 0 },
		sub {
			my ($response) = @_;

			# What, if anything, should we do with "serverModified"?

			my @episodeUUIDs = ();
			if ($response->{'episodes'}) {
				foreach my $upNextEpisode (@{$response->{'episodes'}}) {
					if ($upNextEpisode->{'uuid'}) {
						push(@episodeUUIDs, $upNextEpisode->{'uuid'});
					} else {
						$log->error("Up Next entry missing an episode UUID.");
					}
				}
			} else {
				$log->error("Up Next missing episode list.");
				$callback->();
				return;
			}

			# Cache Up Next for a couple of minutes.
			Plugins::Sprocket::Cache::SetCachedUpNextEpisodeUUIDs(\@episodeUUIDs, 120);

			# Turn the UUIDs into episodes.
			_EpisodeUUIDInflateHelper(\@episodeUUIDs, $callback);
		}
	);
}

sub NewReleaseEpisodes {
	my ($callback) = @_;

	my $cachedEpisodes = Plugins::Sprocket::Cache::GetCachedNewReleaseEpisodes();
	if (defined($cachedEpisodes)) {
		$log->debug("Using cached New Release episodes.");
		_DoAsyncEarlyReturn(sub {
			$callback->($cachedEpisodes);
		});
		return;
	}

	$log->debug("Getting New Release episodes.");
	_GetAPIResponse(
		'https://api.pocketcasts.com/user/new_releases',
		{ },
		sub {
			my ($response) = @_;

			# New releases appears to return very complete podcast details, so no need to
			# inflate UUIDs.
			my @episodes = ();
			if ($response->{'episodes'}) {
				foreach my $newReleaseEpisode (@{$response->{'episodes'}}) {
					if (_IsValidEpisode($newReleaseEpisode)) {
						push(@episodes, $newReleaseEpisode);
					} else {
						$log->error("New Releases invalid episode " . $newReleaseEpisode->{'uuid'} . ".");
					}
				}
			} else {
				$log->error("New Releases missing episode list.");
			}

			# Cache New Releases for a couple of minutes.
			Plugins::Sprocket::Cache::SetCachedInProgressEpisodeUUIDs(\@episodes, 120);

			$callback->(\@episodes);
		}
	);
}

sub InProgressEpisodes {
	my ($callback) = @_;

	my $cachedUUIDs = Plugins::Sprocket::Cache::GetCachedInProgressEpisodeUUIDs();
	if (defined($cachedUUIDs)) {
		$log->debug("Using cached In Progress episodes.");
		# Turn the UUIDs into episodes.
		_EpisodeUUIDInflateHelper($cachedUUIDs, $callback);
		return;
	}

	$log->debug("Getting In Progress episodes.");
	_GetAPIResponse(
		'https://api.pocketcasts.com/user/in_progress',
		{ },
		sub {
			my ($response) = @_;

			my @episodeUUIDs = ();
			if ($response->{'episodes'}) {
				foreach my $upNextEpisode (@{$response->{'episodes'}}) {
					if ($upNextEpisode->{'uuid'}) {
						push(@episodeUUIDs, $upNextEpisode->{'uuid'});
					} else {
						$log->error("In Progress entry missing an episode UUID.");
					}
				}
			} else {
				$log->error("In Progress missing episode list.");
			}

			# Cache In Progress for a couple of minutes.
			Plugins::Sprocket::Cache::SetCachedInProgressEpisodeUUIDs(\@episodeUUIDs, 120);

			# Turn the UUIDs into episodes.
			_EpisodeUUIDInflateHelper(\@episodeUUIDs, $callback);
		}
	);
}

sub StarredEpisodes {
	my ($callback) = @_;

	my $cachedUUIDs = Plugins::Sprocket::Cache::GetCachedStarredEpisodeUUIDs();
	if (defined($cachedUUIDs)) {
		$log->debug("Using cached Starred episodes.");
		# Turn the UUIDs into episodes.
		_EpisodeUUIDInflateHelper($cachedUUIDs, $callback);
		return;
	}

	$log->debug("Getting Starred episodes.");
	_GetAPIResponse(
		'https://api.pocketcasts.com/user/starred',
		{ },
		sub {
			my ($response) = @_;

			my @episodeUUIDs = ();
			if ($response->{'episodes'}) {
				foreach my $upNextEpisode (@{$response->{'episodes'}}) {
					if ($upNextEpisode->{'uuid'}) {
						push(@episodeUUIDs, $upNextEpisode->{'uuid'});
					} else {
						$log->error("Starred entry missing an episode UUID.");
					}
				}
			} else {
				$log->error("Starred missing episode list.");
			}

			# Cache Starred for a couple of minutes.
			Plugins::Sprocket::Cache::SetCachedStarredEpisodeUUIDs(\@episodeUUIDs, 120);

			# Turn the UUIDs into episodes.
			_EpisodeUUIDInflateHelper(\@episodeUUIDs, $callback);
		}
	);
}

sub Subscriptions {
	my ($callback) = @_;

	my $cached = Plugins::Sprocket::Cache::GetCachedSubscriptions();
	if (defined($cached)) {
		$log->debug("Using cached subscriptions.");
		_DoAsyncEarlyReturn(sub {
			$callback->($cached);
		});
		return;
	}

	$log->debug("Getting subscriptions.");
	_GetAPIResponse(
		'https://api.pocketcasts.com/user/podcast/list',
		{ "v" => "1" },
		sub {
			my ($response) = @_;
			my $subscriptions = undef();
			if ($response->{'podcasts'}) {
				$subscriptions = $response->{'podcasts'};
			} else {
				$log->error("Failed to get podcast subscription list.");
			}

			if (defined($subscriptions)) {
				# Cache for a bit.
				Plugins::Sprocket::Cache::SetCachedSubscriptions($subscriptions, 120);
			}

			$callback->($subscriptions);
		}
	);
}

sub _UnpersonalizedEpisodesForPodcast {
	my ($podcast, $callback) = @_;

	if (!$podcast->{'uuid'}) {
		$log->error("Cannot get podcast episodes without podcast UUID.");
		_DoAsyncEarlyReturn(sub {
			$callback->();
		});
		return;
	}

	my $token = _GetAPIToken();
	if (!$token) {
		$log->error("Unable to obtain API token.");
		_DoAsyncEarlyReturn(sub {
			$callback->();
		});
		return;
	}

	my $cached = Plugins::Sprocket::Cache::GetCachedUnpersonalizedEpisodesForPodcast($podcast);
	if ($cached) {
		$log->debug("Using cached unpersonalized episodes for podcast " . $podcast->{'uuid'} . ".");
		_DoAsyncEarlyReturn(sub {
			$callback->($cached);
		});
		return;
	}

	$log->debug("Getting unpersonalized episodes for podcast " . $podcast->{'uuid'} . ".");
	Slim::Networking::SimpleAsyncHTTP->new(
		# Success
		sub {
			my ($response) = @_;
			my $result = eval { from_json($response->content) };

			if (!$result) {
				# Can be a gzip payload with the wrong headers. Our problem is that
				# all the simple Perl modules to do this aren't bundled with the server,
				# and the default Perl installation modules appear to conflict with
				# the slimserver CPAN copies. So follow how Slim::Networking::SimpleAsyncHTTP
				# would gunzip, including its private functions.
				my $compressed = $result;
				Slim::Networking::SimpleAsyncHTTP::_removeGzipHeader(\$compressed);
				my $gz = Compress::Raw::Zlib::Inflate->new(
					-WindowBits => -Compress::Raw::Zlib::MAX_WBITS(),
				);
				my $uncompressed  = undef();
				$gz->inflate($compressed, \$uncompressed);
				if ($uncompressed) {
					$result = eval { from_json($uncompressed) };
				}
			}

			if (!$result || !$result->{'podcast'} || !$result->{'podcast'}->{'episodes'}) {
				$log->error("Could not parse all episodes for podcast ". $podcast->{'uuid'} . ".");
				$callback->();
				return;
			}

			my @unpersonalEpisodes = ();
			foreach my $rawEpisode (@{$result->{'podcast'}->{'episodes'}}) {
				my $episode = {
					uuid => $rawEpisode->{'uuid'},
					url => $rawEpisode->{'url'},
					duration => $rawEpisode->{'duration'},
					title => $rawEpisode->{'title'},
					published => $rawEpisode->{'published'},
					fileType => $rawEpisode->{'file_type'},
					episodeType => $rawEpisode->{'type'},
					podcastTitle => $result->{'podcast'}->{'title'},
					podcastUuid => $result->{'podcast'}->{'uuid'},
				};

				push(@unpersonalEpisodes, $episode);
			}

			if (scalar(@unpersonalEpisodes)) {
				# This doesn't change fast, but isn't browsed often. Short cache.
				Plugins::Sprocket::Cache::SetCacheUnpersonalizedEpisodesForPodcast($podcast, \@unpersonalEpisodes, 60);
				$callback->(\@unpersonalEpisodes);
				return;
			} else {
				$log->error("Could not find unpersonalized episodes for podcast " . $podcast->{'uuid'} . ".");
				$callback->();
				return;
			}
		},
		# Error
		sub {
			my ($http, $error) = @_;
			$log->error("Error retrieving unpersonalized episodes for podcast " . $podcast->{'uuid'} . ".");
			$callback->();
			return;
		},
		# Parameters
		{
			timeout => 15,
		},
	)->get(
		"https://cache.pocketcasts.com/podcast/full/". $podcast->{'uuid'} . "/0/3/2000",
		'Authorization' => 'Bearer ' . $token,
	);
}

sub EpisodesForPodcast {
	my ($podcast, $callback) = @_;

	if (!$podcast->{'uuid'}) {
		$log->error("Cannot get podcast episodes without podcast UUID.");
		_DoAsyncEarlyReturn(sub {
			$callback->();
		});
		return;
	}

	my $token = _GetAPIToken();
	if (!$token) {
		$log->error("Unable to obtain API token.");
		_DoAsyncEarlyReturn(sub {
			$callback->();
		});
		return;
	}

	_UnpersonalizedEpisodesForPodcast($podcast, sub {
		my ($unpersonalEpisodes) = @_;
		if (!$unpersonalEpisodes) {
			# No extra logging, failure already logged.
			$callback->();
			return;
		}

		# Can we entirely service from cache?
		my @cachedEpisodes = ();
		my $cacheOK = 1;
		foreach my $unpersonalEpisode (@{$unpersonalEpisodes}) {
			my $cachedEpisode = Plugins::Sprocket::Cache::GetCachedEpisodeForUUID($unpersonalEpisode->{'uuid'});
			if (!$cachedEpisode) {
				$log->debug("Missing cached personalized episode " . $unpersonalEpisode->{'uuid'} . ".");
				$cacheOK = 0;
				last;
			}
			push(@cachedEpisodes, $cachedEpisode);
		}
		if ($cacheOK) {
			$log->debug("Using cached personalized episodes for podcast " . $podcast->{'uuid'} . ".");
			$callback->(\@cachedEpisodes);
			return;
		}

		$log->debug("Getting listen states for podcast " . $podcast->{'uuid'} . ".");
		_GetAPIResponse(
			'https://api.pocketcasts.com/user/podcast/episodes',
			{ "uuid" => $podcast->{'uuid'} },
			sub {
				my ($response) = @_;
				if (!$response->{'episodes'}) {
					$log->error("Failed to get podcast episode listen states.");
					$callback->();
					return;
				}

				# Break out states by UUID for lookup.
				my $listenStateByUUID = {};
				foreach my $listenState (@{$response->{'episodes'}}) {
					if (!$listenState->{'uuid'}) {
						# Treat this as fatal.
						$log->error("Episode listen state missing UUID.");
						$callback->();
						return;
					}
					$listenStateByUUID->{$listenState->{'uuid'}} = $listenState;
				}

				my @episodes = ();
				foreach my $episode (@{$unpersonalEpisodes}) {
					my $listenState = $listenStateByUUID->{$episode->{'uuid'}};
					if ($listenState) {
						$episode->{playedUpTo} = $listenState->{'playedUpTo'};
						$episode->{starred} = $listenState->{'starred'};
						$episode->{playingStatus} = $listenState->{'playingStatus'};
						$episode->{isDeleted} = $listenState->{'isDeleted'};
					} else {
						$episode->{playedUpTo} = 0;
						$episode->{starred} = 0;
						$episode->{playingStatus} = PlayStatusUnplayed;
						$episode->{isDeleted} = 0;
					}
					if (_IsValidEpisode($episode)) {
						push(@episodes, $episode);

						# Cache for the length of the episode at least.
						my $timeout = $episode->{'duration'};
						if (!$timeout) {
							$timeout = 600;	 # Best we can do.
						}
						Plugins::Sprocket::Cache::SetCachedEpisode($episode, $timeout);
					} else {
						$log->debug("Invalid generated episode " . $episode->{'uuid'} . ".");
					}
				}

				if (scalar(@episodes)) {
					$callback->(\@episodes);
					return;
				} else {
					$log->error("Could not personalize episodes for podcast " . $podcast->{'uuid'} . ".");
					$callback->();
					return;
				}
			}
		);

	});
}

sub PodcastIconURL {
	my ($podcast) = @_;
	if ($podcast->{'uuid'}) {
		return "https://static2.pocketcasts.com/discover/images/400/" . $podcast->{'uuid'} . ".jpg"
	} else {
		return undef();
	}
}

sub EpisodeIconURL {
	my ($episode) = @_;
	if ($episode->{'podcastUuid'}) {
		return "https://static2.pocketcasts.com/discover/images/400/" . $episode->{'podcastUuid'} . ".jpg"
	} else {
		return undef();
	}
}

sub UpdateEpisodePlayStatus {
	my ($episode, $position, $playStatus, $callback) = @_;

	$position = int($position);
	if (($position < 0) || ($position > $episode->{'duration'})) {
		$log->error("Invalid episode position!");
		_DoAsyncEarlyReturn(sub {
			$callback->();
		});
		return;
	}

	if (!_IsValidPlayStatus($playStatus)) {
		$log->error("Invalid episode play status!");
		_DoAsyncEarlyReturn(sub {
			$callback->();
		});
		return;
	}

	if (!($episode->{'uuid'} && $episode->{'podcastUuid'})) {
		_DoAsyncEarlyReturn(sub {
			$callback->();
		});
		return;
	}

	my $params = {
		'uuid' => $episode->{'uuid'},
		'podcast' => $episode->{'podcastUuid'},
		'position' => $position,
		'status' => $playStatus,
	};

	_GetAPIResponse(
		'https://api.pocketcasts.com/sync/update_episode',
		$params,
		sub {
			my ($response) = @_;

			# Response is empty so there's nothing to do here but update caches. This is safe
			# even if the response was an error.
			Plugins::Sprocket::Cache::InvalidateCachedEpisode($episode);
			# Change in play state might make something in progress.
			Plugins::Sprocket::Cache::InvalidateInProgressCachedEpisodeUUIDs();

			# Seed the cache and hand back the updated episode.
			EpisodeFromUUID($episode->{'uuid'}, $callback);
		}
	);
}

sub SetEpisodeAsCurrentUpNext {
	my ($episode, $callback) = @_;

	if (!($episode->{'uuid'} && $episode->{'podcastUuid'})) {
		return;
	}

	my $params = {
  		'version' => 2,
	  	'episode' => {
  			'uuid' => $episode->{'uuid'},
	  		'podcast' => $episode->{'podcastUuid'},
		},
 	};

	_GetAPIResponse(
		'https://api.pocketcasts.com/up_next/play_now',
		$params,
		sub {
			my ($response) = @_;

			# Response seems to have new Up Next, but its incomplete, so ignore.

			# Any cached Up Next is invalid.
			Plugins::Sprocket::Cache::InvalidateUpNextCachedEpisodeUUIDs();

			$callback->();
		}
	);
}

sub RemoveEpisodeFromUpNext {
	my ($episode, $callback) = @_;

	if (!$episode->{'uuid'}) {
		return;
	}

	my $params = {
  		'version' => 2,
	  	'uuids' => [ $episode->{'uuid'} ],
 	};

	_GetAPIResponse(
		'https://api.pocketcasts.com/up_next/remove',
		$params,
		sub {
			my ($response) = @_;

			# Response seems to have new Up Next, but its incomplete, so ignore.

			# Any cached Up Next is invalid.
			Plugins::Sprocket::Cache::InvalidateUpNextCachedEpisodeUUIDs();

			$callback->();
		}
	);
}

##############################################
#
#	 Utility
#
##############################################

sub _IsValidPlayStatus {
	my ($playStatus) = @_;

	if (($playStatus == PlayStatusUnplayed) || ($playStatus == PlayStatusPlaying) || ($playStatus == PlayStatusPlayed)) {
		return 1;
	} else {
		return 0;
	}
}

sub _IsValidEpisode {
	my ($episode) = @_;
	if (defined($episode->{'uuid'}) &&
		defined($episode->{'url'}) &&
		# Some episodes do not have duration set (undef) or have zero duration. This
		# appears to only apply to old episodes (perhaps before they scanned all episodes?).
		# Filter these off for now. Even though we could get the data from scanning, we don't
		# want to have to update the model everywhere.
		defined($episode->{'duration'}) && $episode->{'duration'} &&
		defined($episode->{'title'}) &&
		# Some responses fail to include proper podcast details while still defining the field.
		defined($episode->{'podcastTitle'}) && $episode->{'podcastTitle'} &&
		defined($episode->{'podcastUuid'}) && $episode->{'podcastUuid'} &&
		defined($episode->{'playingStatus'}) &&
		defined($episode->{'playedUpTo'})) {
		return 1;
	} else {
		return 0;
	}
}

1;
