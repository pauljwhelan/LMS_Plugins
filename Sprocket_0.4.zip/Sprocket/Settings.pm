# Copyright (c) 2019 Alex Harper
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are
# met:
#
#     (1) Redistributions of source code must retain the above copyright
#     notice, this list of conditions and the following disclaimer.
#
#     (2) Redistributions in binary form must reproduce the above copyright
#     notice, this list of conditions and the following disclaimer in
#     the documentation and/or other materials provided with the
#     distribution.
#
#     (3)The name of the author may not be used to
#     endorse or promote products derived from this software without
#     specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
# IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
# WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
# DISCLAIMED. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT,
# INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
# (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
# SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
# HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
# STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
# IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
# POSSIBILITY OF SUCH DAMAGE.

package Plugins::Sprocket::Settings;

use strict;
use warnings;
use base qw(Slim::Web::Settings);

use Slim::Utils::Log;
use Slim::Utils::Prefs;
use Slim::Utils::Strings qw(string cstring);

use Plugins::Sprocket::API;

my $log = logger('plugin.sprocket');
my $prefs = preferences('plugin.sprocket');

# Default preference values.
$prefs->init({
	'username' => '',
	'authToken' => '',
	'browseEpisodeSort' => Plugins::Sprocket::API::EpisodeSortDescending,
	'integratePlaybackState' => 1,
	'integrateUpNextCurrentlyPlaying' => 1,
	'integrateUpNextRemovePlayed' => 1,
	'playbackSpeed' => '1.0',
	'playbackSkipButtons' => 0,
	'playbackSkipBackwardsSeconds' => '10',
	'playbackSkipForwardsSeconds' => '30',
});

sub name {
	return Slim::Web::HTTP::CSRF->protectName('PLUGIN_SPROCKET_LONG_NAME');
}

sub page {
	return Slim::Web::HTTP::CSRF->protectURI('plugins/Sprocket/settings/basic.html');
}

sub beforeRender {
	my ($class, $params) = @_;

	# Restore values from prefs.
	$params->{'prefs'}->{'browseEpisodeSort'} = BrowseEpisodeSort();
	$params->{'prefs'}->{'integratePlaybackState'} = IntegratePlaybackState();
	$params->{'prefs'}->{'integrateUpNextCurrentlyPlaying'} = IntegrateUpNextCurrentlyPlaying();
	$params->{'prefs'}->{'integrateUpNextRemovePlayed'} = IntegrateUpNextRemovePlayed();
	$params->{'prefs'}->{'playbackSpeed'} = PlaybackSpeed();
	$params->{'prefs'}->{'playbackSkipButtons'} = PlaybackSkipButtons();
	$params->{'prefs'}->{'playbackSkipBackwardsSeconds'} = PlaybackSkipBackwardsSeconds();
	$params->{'prefs'}->{'playbackSkipForwardsSeconds'} = PlaybackSkipForwardsSeconds();
}

sub handler {
	my ($class, $client, $params) = @_;

	if ($params->{'saveSettings'}) {
		if ($params->{'logout'}) {
			$prefs->set('username', '');
			$prefs->set('authToken', '');
		} elsif ($params->{'username'}) {
			my $username = $params->{'username'};
			$prefs->set('username', $username ? $username : '');
			if ($params->{'password'}) {
				my $password = $params->{'password'} ? $params->{'password'} : '';
				if ($password) {
					my $token = Plugins::Sprocket::API::DoSyncLogin($username, $password);
					if ($token) {
						$prefs->set('authToken', $token ? $token : '');
					}
				}
			}
		}
		if ($params->{'browseEpisodeSort'}) {
			my $browseEpisodeSort = $params->{'browseEpisodeSort'};
			$prefs->set('browseEpisodeSort', "$browseEpisodeSort");
		}
		$prefs->set('integratePlaybackState', $params->{'integratePlaybackState'} ? 1 : 0);
		$prefs->set('integrateUpNextCurrentlyPlaying', $params->{'integrateUpNextCurrentlyPlaying'} ? 1 : 0);
		$prefs->set('integrateUpNextRemovePlayed', $params->{'integrateUpNextRemovePlayed'} ? 1 : 0);
		if ($params->{'playbackSpeed'}) {
			my $playbackSpeed = $params->{'playbackSpeed'};
			$prefs->set('playbackSpeed', "$playbackSpeed");
		}
		$prefs->set('playbackSkipButtons', $params->{'playbackSkipButtons'} ? 1 : 0);
		if ($params->{'playbackSkipBackwardsSeconds'}) {
			my $skipBackwardSecs = $params->{'playbackSkipBackwardsSeconds'};
			$prefs->set('playbackSkipBackwardsSeconds', "$skipBackwardSecs");
		}
		if ($params->{'playbackSkipForwardsSeconds'}) {
			my $skipForwardSecs = $params->{'playbackSkipForwardsSeconds'};
			$prefs->set('playbackSkipForwardsSeconds', "$skipForwardSecs");
		}
	}

	# Configure auth token display.
	if (AuthToken()) {
		$params->{'needsLogin'} = 0;
	} else {
		$params->{'needsLogin'} = 1;
	}

	# Restore values from prefs.
	$params->{'prefs'}->{'username'} = $prefs->get('username');
	$params->{'prefs'}->{'browseEpisodeSort'} = BrowseEpisodeSort();
	$params->{'prefs'}->{'integratePlaybackState'} = IntegratePlaybackState();
	$params->{'prefs'}->{'integrateUpNextCurrentlyPlaying'} = IntegrateUpNextCurrentlyPlaying();
	$params->{'prefs'}->{'integrateUpNextRemovePlayed'} = IntegrateUpNextRemovePlayed();
	$params->{'prefs'}->{'playbackSpeed'} = PlaybackSpeed();
	$params->{'prefs'}->{'playbackSkipButtons'} = PlaybackSkipButtons();
	$params->{'prefs'}->{'playbackSkipBackwardsSeconds'} = PlaybackSkipBackwardsSeconds();
	$params->{'prefs'}->{'playbackSkipForwardsSeconds'} = PlaybackSkipForwardsSeconds();

	return $class->SUPER::handler($client, $params);
}

##############################################
#
#  Prefs Accessors
#
##############################################

sub AuthToken {
	return $prefs->get('authToken') ? $prefs->get('authToken') : undef();
}

sub BrowseEpisodeSort {
	return $prefs->get('browseEpisodeSort') ? $prefs->get('browseEpisodeSort') : Plugins::Sprocket::API::EpisodeSortDescending;
}

sub IntegratePlaybackState {
	return $prefs->get('integratePlaybackState') ? 1 : 0;
}

sub IntegrateUpNextCurrentlyPlaying {
	return $prefs->get('integrateUpNextCurrentlyPlaying') ? 1 : 0;
}

sub IntegrateUpNextRemovePlayed {
	return $prefs->get('integrateUpNextRemovePlayed') ? 1 : 0;
}

sub PlaybackSpeed {
	return $prefs->get('playbackSpeed') ? $prefs->get('playbackSpeed') : '1.0';
}

sub PlaybackSkipButtons {
	return $prefs->get('playbackSkipButtons') ? 1 : 0;
}

sub PlaybackSkipBackwardsSeconds {
	return $prefs->get('playbackSkipBackwardsSeconds') ? $prefs->get('playbackSkipBackwardsSeconds') : '10';
}

sub PlaybackSkipForwardsSeconds {
	return $prefs->get('playbackSkipForwardsSeconds') ? $prefs->get('playbackSkipForwardsSeconds') : '30';
}

1;
